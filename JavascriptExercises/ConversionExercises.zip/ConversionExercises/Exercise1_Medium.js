const exercise2 = {
  initialForm: [
    {
      name: "A",
      value: 30,
    },
    {
      name: "A",
      value: 20,
    },
    {
      name: "B",
      value: 30,
    },
    {
      name: "B",
      value: 40,
    },
  ],
  expectedForm: [
    {
      name: "A",
      value: 50,
    },
    {
      name: "B",
      value: 70,
    },
  ],

  //You must convert initialForm object to be the same as expectedForm
  //Use this function
  execute: function (initialForm) {
    const result = [];
    // conversion code here

    return result;
  },
};

addCategory(categories.conversion, exercise2, "Exercise 1 Medium");
